// 5 elementos ordenados (Frutas)
const frutas = ["Fresa", "Cereza", "Sandía", "Frambuesa", "Pitaya"];

// cual es el tercer elemento? (Índice 2)
console.log("El tercer elemento es: " + frutas[2]);

// como funciona push() y pop()
frutas.push("Mora"); //se manda al final
console.log("Arreglo tras push: ", frutas);

let eliminado = frutas.pop(); // Elimina lo del final
console.log("Elemento eliminado con pop: " + eliminado);
console.log("Arreglo final: ", frutas);

//rositas y sus for?

const coloresRosados = ["Pastel", "Fucsia", "Chicle", "Salmón"];

// For promedio
console.log("--- Iteración con Ciclo For ---");
for (let i = 0; i < coloresRosados.length; i++) {
  console.log(`Índice ${i}: ${coloresRosados[i]}`);
}

// forEach()
console.log("--- Iteración con forEach ---");
coloresRosados.forEach((color, index) => {
  console.log(`Color ${index}: ${color}`);
});

// Operaciones con arreglos numéricos

const grupoA = [5, 12, 8, 20];
const grupoB = [8, 15, 3, 20];

// Unión simple
const union = grupoA.concat(grupoB);
console.log("Arreglos concatenados: ", union);

// Discriminación: Números en A no en B
const diferencia = grupoA.filter((num) => !grupoB.includes(num));
console.log("Diferencia (A - B): ", diferencia);

// Filtro: Números mayores a 10
const mayoresADiez = union.filter((num) => num > 10);
console.log("Números > 10: ", mayoresADiez);

// Ciclo While: Suma del 1 al 10
let suma = 0;
let contador = 1;
while (contador <= 10) {
  suma += contador;
  contador++;
}
console.log("Suma total (1-10) con While: " + suma);

// Ciclo Do/While: Números del 5 al 15
let numDo = 5;
console.log("--- Números del 5 al 15 ---");
do {
  console.log(numDo);
  numDo++;
} while (numDo <= 15);

// For Anidado: Tablas de multiplicar (1 al 5)
console.log("--- Tablas de Multiplicar (1-5) ---");
for (let i = 1; i <= 5; i++) {
  console.log(`Tabla del ${i}:`);
  for (let j = 1; j <= 10; j++) {
    console.log(`${i} x ${j} = ${i * j}`);
  }
}
