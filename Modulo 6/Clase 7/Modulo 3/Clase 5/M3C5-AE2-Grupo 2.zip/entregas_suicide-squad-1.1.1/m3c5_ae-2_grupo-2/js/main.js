const form = document.querySelector('form');
const inputName = document.querySelector('#name');
const inputAge = document.querySelector('#age');
const inputHeight = document.querySelector('#height');
const inputPosition = document.querySelector('#position');

form.addEventListener('submit', (e) => {
  e.preventDefault();
  const name = inputName.value;
  const age = Number(inputAge.value);
  const height = Number(inputHeight.value);
  const position = inputPosition.value;

  console.log(name, typeof name);
  console.log(age, typeof age);

  const res =
    name && age >= 15 && height >= 160 && position ? 'Inscrito' : 'No inscrito';

  const ageRequired = age < 15 && 'Debes ser mayor de 15 años';
  const heightRequired = height < 160 && 'Debes medir al menos 160 cm';

  if (res === 'No inscrito') {
    if (ageRequired && heightRequired) {
      alert(ageRequired + '\n' + heightRequired);
      return;
    }
    if (ageRequired) {
      alert(ageRequired);
    }
    if (heightRequired) {
      alert(heightRequired);
    }
  }
  if (res === 'Inscrito') {
    if (age <= 18) {
      alert('Jugador Inscrito en categoría juvenil');
    }
    if (age > 18) {
      alert('Jugador Inscrito en categoría adulto');
    }
  }
});
